# Changelog

## [1.3.0]
 
### Updated
- Update libs
 
## [1.2.0]
 
### Updated
- Update libs
- Merge PR 
 
## [1.1.0]

### Updated

Following libs have beed updated to the recent versions:
- React - 16.7.1
- React-router - 4.3.1
- Reactstrap - 7.1.0

## [1.0.0]

### New Features

- Shadow added to image
