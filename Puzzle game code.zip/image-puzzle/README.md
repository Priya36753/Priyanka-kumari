# image-puzzle-js
Image Puzzle game in pure JavaScript.
Detailed description and documentation available at: https://www.codeproject.com/Articles/810978/Image-Puzzle-A-Html-Game
