# nodejs-chat-app

Node.js chat app created with WebSocket ([Socket.IO](https://socket.io/)), HTML5 and jQuery.

To start the app, make sure you have [Node.js properly installed](https://nodejs.org/en/download/) and run the command:

    node app.js