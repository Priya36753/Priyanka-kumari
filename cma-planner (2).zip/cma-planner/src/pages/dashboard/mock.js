export const mock = [
  {
    id: 123325,
    updatedAt: '2019-11-14',
    title: ' React Native Starter - Mobile Template'
  },
  {
    id: 56785,
    updatedAt: '2019-12-14',
    title: 'Light Blue React Node.js - update version 7.0.1'
  },
  {
    id: 943325,
    updatedAt: '2019-15-14',
    title: 'Sing App React Node.js - update version 7.0.1'
  },
  {
    id: 84767,
    updatedAt: '2019-10-14',
    title: 'Sing App Vue Node.js - update version 5.0.3'
  },
  {
    id: 889412,
    updatedAt: '2019-11-14',
    title: 'Light Blue Vue Node.js - update version 3.0.5'
  },
]